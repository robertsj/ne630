NE 630 Lesson 12 handout source

Files:
  lesson_12_handout.tex       document wrapper; set \handoutsolutionstrue for a solution copy
  lesson_12_handout_body.tex  handout body with blanks and solution payloads
  ne630boardhandout.cls     shared document class

Compile the public, non-solution handout with XeLaTeX:

  latexmk -xelatex -interaction=nonstopmode -halt-on-error lesson_12_handout.tex

The committed wrapper sets \handoutsolutionsfalse and therefore reproduces the
published PDF. To make a private solution copy, change that one line to
\handoutsolutionstrue before compiling. Do not publish generated source with
solutions enabled.

Myriad Pro is used when it is installed in one of the paths recognized by the
class; otherwise the class falls back to TeX Gyre Heros. Libertinus Math and
the standard packages named by the class are also required.
