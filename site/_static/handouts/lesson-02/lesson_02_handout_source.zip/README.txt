NE 630 Lesson 02 student handout source

Files:
  lesson_02_handout.tex       student document wrapper
  lesson_02_handout_body.tex  student-safe handout body
  ne630boardhandout.cls     shared document class

Compile with XeLaTeX:

  latexmk -xelatex -interaction=nonstopmode -halt-on-error lesson_02_handout.tex

The public body intentionally omits instructor reveal values, instructor-only
figures, and teaching cues. Myriad Pro is used when it is installed in one of
the paths recognized by the class; otherwise the class falls back to TeX Gyre
Heros. Libertinus Math and the standard packages named by the class are also
required.
