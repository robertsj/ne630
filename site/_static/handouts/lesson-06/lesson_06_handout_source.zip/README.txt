NE 630 Lesson 06 handout source

Files:
  lesson_06_handout.tex       document wrapper; set \handoutsolutionstrue for a solution copy
  lesson_06_handout_body.tex  handout body with blanks and solution payloads
  ne630boardhandout.cls     shared document class
  figures/h1_xsec.pgf      supporting figure
  figures/u235_fission.pgf supporting figure
  figures/u238_threshold.ipynb OpenMC plot-source notebook
  figures/u238_threshold.pdf supporting figure

Compile the public, non-solution handout with XeLaTeX:

  latexmk -xelatex -interaction=nonstopmode -halt-on-error lesson_06_handout.tex

The committed wrapper sets \handoutsolutionsfalse and therefore reproduces the
published PDF. To make a private solution copy, change that one line to
\handoutsolutionstrue before compiling. Do not publish generated source with
solutions enabled.

Myriad Pro is used when it is installed in one of the paths recognized by the
class; otherwise the class falls back to TeX Gyre Heros. Libertinus Math and
the standard packages named by the class are also required.
